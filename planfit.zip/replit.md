# Planfit40

A fitness tracking progressive web app for women, focused on consistency-based level progression.

## Architecture

- **Single-file app**: `index.html` — React 18 (via CDN) + Babel standalone, all CSS and JS inline
- **Server**: `server.py` — Python's built-in `http.server` serving static files on port 5000
- **Storage**: `localStorage` (client-side only, no backend)

## Features

- Login with name, email, and fitness level selection
- Daily workout check-in tracking
- Progress bar and level system (6 levels: Beginner → Advanced III)
- 40-day cycle per level, with early unlock at 36 days (90%)
- Visual 30-day calendar of past check-ins
- Community feed and testimonials
- Multilingual: Portuguese, Spanish, English
- Animated modals for check-in and level-up events
- Bottom navigation: Dashboard, Feed, Community, Guide, Profile

## Levels

1. Iniciante / Beginner — 🌱
2. Intermediário I / Intermediate I — ⚡
3. Intermediário II / Intermediate II — 🔥
4. Avançado I / Advanced I — 🏆
5. Avançado II / Advanced II — 💎
6. Avançado III / Advanced III — 👑

## Running

The app starts automatically via the "Start application" workflow using `python server.py`.
